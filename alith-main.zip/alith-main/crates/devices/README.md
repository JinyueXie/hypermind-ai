# alith-devices: Managing Devices and Builds for LLMs

This crate is a fork of [llm_client](https://github.com/ShelbyJenkins/llm_client).
