//! Reference: https://dagrs.com/docs/getting-started/components
pub use dagrs::{
    Action, Content, DefaultNode, EmptyAction, EnvVar, Graph, InChannels, Node, NodeId, NodeName,
    NodeTable, OutChannels, Output, RecvErr, SendErr, auto_node, dependencies,
};
