# The Easiest Rust Interface for Local LLMs 

This a fork of [llm_client](https://github.com/ShelbyJenkins/llm_client).
