mod req;
mod res;
pub use req::AnthropicCompletionRequest;
pub use res::AnthropicCompletionResponse;
