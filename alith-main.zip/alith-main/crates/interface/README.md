# alith-interface: The Backend for the alith-client Crate

This crate is a fork of [llm_client](https://github.com/ShelbyJenkins/llm_client).
