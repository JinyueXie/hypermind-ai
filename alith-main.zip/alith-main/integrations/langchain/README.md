# Langchain Alith Integration

This integration provides the following methods:

1. **Enable the Alith chain in Langchain**: We can use the Alith as the LLM node for the existing Langchain workflow and get the performance gains of Alith.
