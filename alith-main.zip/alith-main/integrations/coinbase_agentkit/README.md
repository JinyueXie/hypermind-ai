# Coinbase Agentkit Alith Integration

This integration provides the following methods:

1. **Use Agentkit actions within Alith**: You can directly leverage a variety of actions from the agentkit ecosystem without the need to rewrite them in Alith.

## Reference

- [Agentkit GitHub](https://github.com/coinbase/agentkit)
