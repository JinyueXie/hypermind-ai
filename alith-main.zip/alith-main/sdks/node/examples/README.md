# Alith Node Examples

- [Simple Agent](./agent.ts)
- [Agent with Tools](./agent_with_tools.ts)
- [Agent Based on DeepSeek Chat Models](./agent_deepseek.ts)
- [Agent Based on Grok Chat Models](./agent_grok.ts)
