from alith import FastEmbeddings

print(FastEmbeddings().embed_texts(["Hello", "World"]))
