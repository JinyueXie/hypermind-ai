from typing import Mapping

Headers = Mapping[str, str]
